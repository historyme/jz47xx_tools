#ifndef __iso646_h__
#define __iso646_h__

#define compl ~
// Non-Standard
#define compl_eq ~=

#define not !
#define not_eq !=

#define bitand &
#define and_eq &=

#define bitor |
#define or_eq |=

#define xor ^
#define xor_eq ^=

#define and &&
#define or ||


#endif
