#ifndef __fgl_sphere_h__
#define __fgl_sphere_h__

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdint.h>

extern void fgl_draw_sphere(uint32_t inDetail);

#ifdef __cplusplus
}
#endif

#endif
